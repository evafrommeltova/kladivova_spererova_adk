#include "ispointidentical.h"
